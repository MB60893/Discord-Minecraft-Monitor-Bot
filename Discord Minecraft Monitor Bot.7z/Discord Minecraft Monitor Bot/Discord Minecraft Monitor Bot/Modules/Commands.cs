﻿using Discord;
using Discord.Commands;
using System;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.IO;
using System.Net;

namespace MineMonBot.Modules {
	// for commands to be available, and have the Context passed to them, we must inherit ModuleBase
	public class CommandList : ModuleBase {

        static string GetIPAddress() {
            String address = "";
			WebRequest request = WebRequest.Create("http://checkip.dyndns.org/");
            using (WebResponse response = request.GetResponse())
            using (StreamReader stream = new StreamReader(response.GetResponseStream())) {
                address = stream.ReadToEnd();
            }

            int first = address.IndexOf("Address: ") + 9;
            int last = address.LastIndexOf("</body>");
            address = address[first..last];

            return address;
        }

        [Command("ip")]
        public async Task IPCommand() {
            var sb = new StringBuilder();

            sb.Append(GetIPAddress());

            // send simple string reply
            await ReplyAsync(sb.ToString());
        }
    }
}